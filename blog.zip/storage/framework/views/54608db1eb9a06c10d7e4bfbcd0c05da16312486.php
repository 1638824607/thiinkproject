<?php $__env->startSection('content'); ?>
    <!--面包屑导航 开始-->
    <div class="crumb_warp">
        <i class="fa fa-home"></i> <a href="<?php echo e(url('admin/info')); ?>">首页</a> &raquo;文章管理
    </div>
    <!--面包屑导航 结束-->
	<!--结果页快捷搜索框 开始-->
	<div class="search_wrap">
        <form action="<?php echo e(url('admin/article/search')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <table class="search_tab">
                <tr>
                    <th width="120">选择分类:</th>
                    <td>
                        <select name="cate_id">
                            <option value="0">请选择..</option>
                            <?php foreach($cate as $c): ?>
                                <option value="<?php echo e($c->cate_id); ?>" <?php if($c->cate_id==$cate_id): ?> selected="selected"<?php endif; ?>><?php echo e($c->_cate_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <th width="70">关键字:</th>
                    <td><input type="text" name="art_tag" placeholder="关键字" value="<?php echo e($art_tag); ?>"></td>
                    <td><input type="submit" name="sub" value="查询"></td>
                </tr>
            </table>
        </form>
    </div>
    <!--结果页快捷搜索框 结束-->
    <!--搜索结果页面 列表 开始-->
        <div class="result_wrap">
            <!--快捷导航 开始-->
            <div class="result_content">
                <div class="short_wrap">
                    <a href="<?php echo e(url('admin/article/create')); ?>"><i class="fa fa-plus"></i>新增文章</a>
                    <a href="<?php echo e(url('admin/article/search')); ?>"><i class="fa fa-recycle"></i>全部文章</a>
                </div>
            </div>
            <!--快捷导航 结束-->
        </div>
        <div class="result_wrap">
            <div class="result_content">
                <table class="list_tab">
                    <tr>
                        <th class="tc">ID</th>
                        <th>标题</th>
                        <th>点击</th>
                        <th>编辑</th>
                        <th>发布时间</th>
                        <th>操作</th>
                    </tr>
                    <?php foreach($data as $v): ?>
                    <tr>
                        <td class="tc"><?php echo e($v->art_id); ?></td>
                        <td>
                            <a href="#"><?php echo e($v->art_title); ?></a>
                        </td>
                        <td><?php echo e($v->art_view); ?></td>
                        <td><?php echo e($v->art_editor); ?></td>
                        <td><?php echo e(date('Y-m-d',$v->art_time)); ?></td>
                        <td>
                            <a href="<?php echo e(url('admin/article/'.$v->art_id.'/edit')); ?>">修改</a>
                            <a href="javascript:;" onclick="delArt(<?php echo e($v->art_id); ?>)">删除</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <div class="page_list">
                    <?php if($flag=='0'): ?>
                        <?php echo e($data->links()); ?>

                    <?php else: ?>
                        <?php echo $data->appends(['cate_id'=>$cate_id,'art_tag'=>$art_tag])->render(); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    <style>
        .result_content ul li span{
            font-size: 15px;
            padding:6px 12px;
        }
    </style>
    <script>
        function delArt(art_id){
            layer.confirm('您确定要删除这篇文章吗?',{
                btn: ['确定','取消']
            },function(){
                $.post("<?php echo e(url('admin/article/')); ?>/"+art_id,{'_method':'delete','_token':"<?php echo e(csrf_token()); ?>"},function(data){
                    if(data['status']==0){
                        location.href = location.href;
                        layer.msg(data.msg,{icon:6});
                    }else{
                        layer.msg(data.msg,{icon:5});
                    }
                });
            },function(){
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>