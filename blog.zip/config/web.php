<?php return array (
  'web_title' => '如祥个人博客',
  'web_count' => '1111111112',
  'web_post' => 'women',
  'web_img' => '0',
  'seo_title' => '技术宅',
  'keywords' => '百度一下',
  'description' => '百度一下',
  'copyright' => 'Design by 神博客 http://www.shenblog.cn 网站统计',
);